module.exports = {
  host     : '13.124.212.110',
  user     : 'cyyworld',
  password : 'Dbwjd12!@',
  database : 'soocore'
};