const API_URL = "https://api.soo-core.com"
const WEB_URL = "https://soo-core.com"
module.exports = {
  API_URL: API_URL,
  WEB_URL: WEB_URL
}