<template>
  <div class="flex auto column" style="height:100%;">
    <div class="title">soocore</div>
    <div @click="$router.push('add')" class="flex auto align-items-center justify-content-center column" v-if="!sectionList.length">
      <div class="flex icon-plus" style="font-size:30vw; color:#D8695E;"></div>
    </div>
    <template v-else>
      <div class="flex none" style="widthL100%; height:20vw; padding:0 4vw; border-bottom:1vw dashed rgba(33, 38, 46, 0.3);">
        <div class="flex auto align-items-center">
          <input class="search-input" style="height:10vw;" placeholder="갑, 을, 보상 검색" v-model="keyword" @keydown="onKeydown" />
          <div @click="serachKeyword" class="flex none search-icon justify-content-center align-items-center" style="height:10vw; width:10vw;">
            <div class="icon-search" style="font-size:6vw; color:#ffffff;"></div>
          </div>
        </div>
        <div @click="$router.push('add')" class="flex auto align-items-center">
          <div class="flex auto icon-plus justify-content-center" style="font-size:10vw; color:#D8695E;"></div>
        </div>
      </div>
      <div class="flex auto" style="position:relative;">
        <scroller ref="scroller" :on-refresh="refresh">
            <div style="margin:0 auto; width:90%; margin-bottom:4vw; padding-top:4vw; position:relative;">
              <div v-for="(section,index) of filteredSectionList.slice((currentPage-1)*pageSize, (currentPage-1)*pageSize+pageSize)" :key="'main-list'+index" style="position:relative;">
                <div v-if="checkSection(section) == 1" class="icon-crown" style="color:#F2D677; font-size:6vw; padding:0; margin:0;"/>
                <div
                  :id="`mainSection${section.id}`"
                  v-on:mousedown="onMouseDown($event, section)"
                  v-on:mouseup="onMouseUp($event, section)"
                  v-on:touchstart="onMouseDown($event, section)"
                  v-on:touchend="onMouseUp($event, section)"
                  class="flex none column justify-content-center content" style="z-index:2;"> 
                    <div class="flex auto column" style="margin:6vw 4vw;">
                      <div class="flex">
                        <div class="flex auto justify-content-start align-items-center">
                          <div class="flex none circle justify-content-center align-items-center">갑</div>
                          <div>{{section.a_name}}</div>
                        </div>
                        <div class="flex auto justify-content-end align-items-center">
                          <div class="flex none circle justify-content-center align-items-center" style="background:#F2D677;">을</div>
                          <div>{{section.b_name}}</div>
                        </div>
                      </div>

                      <div class="flex none column justify-content-center">
                        <div class="flex none progress-bar-bg">
                          <div v-if="section.score > 0 " class="flex none progress-bar" :style="{
                            width:getProgressWidth(section.goalpoint, section.score)
                          }"></div>
                        </div>
                      </div>

                      <div class="flex auto align-items-center" style="margin-top:5vw;">
                        <div class="flex none column justify-content-start" style="font-size:5vw;">
                          <div class="flex auto justify-content-start">
                            <div class="flex none score-text">
                              점수
                            </div>
                          </div>
                          <div class="flex none align-items-center goal-text">
                            달성 보상
                          </div>
                        </div>
                        <div class="flex auto column justify-content-end" style="font-size:5vw;">
                          <div class="flex auto justify-content-end">
                            <div class="flex none score-text" :style="{
                            color:'#D8695E', 
                            fontWeight:'bold'
                            }">
                              {{section.score}}/
                            </div>
                            <div class="flex none score-text">
                              {{section.goalpoint}}
                            </div>
                          </div>
                          <div class="flex auto align-items-center justify-content-end goal-text">
                            {{section.goal}}
                          </div>
                        </div>
                      </div>
                      <template v-if="!section.isCreate">
                        <div class="flex align-items-center justify-content-center invite-mask">
                          초대하기
                        </div>
                      </template>
                      <template v-else>
                        <div v-if="checkSection(section) == -1 " class="flex align-items-center justify-content-center fail-mask">
                          실패
                        </div>
                        <div v-if="checkSection(section) == 1" class="flex align-items-center justify-content-center success-mask">
                          성공
                        </div>
                      </template>
                    </div>
                  </div>
                  <div @click.stop="onClickDelete(section)" class="flex none justify-content-center align-items-center" 
                  style="z-index:1; width:20vw; position:absolute; right:0; top:50%; transform:translate(0, -50%); ">
                    <div class="icon-trash-empty title-icon" style="font-size:10vw; padding:0; margin:0;"/>
                  </div>
              </div>
            </div>
        </scroller>
      </div>
    
      <div class="flex none justify-content-center align-items-center" style="height:14vw;">
        <div @click="leftPage" class="flex none icon-angle-left" style="font-weight:bold; color:#595959; font-size:8vw;" :style="{
          opacity:currentPage>1 ? 1 : 0.4
          }"></div>
        <div class="flex none justify-content-center white-button" style="width:10vw; height:10vw; border-radius:2vw; font-size:6vw;">{{currentPage}}</div>
        <div @click="rightPage" class="flex none icon-angle-right" style="font-weight:bold; color:#595959; font-size:8vw;" :style="{
          opacity: (currentPage*pageSize < sectionList.length) ? 1 : 0.4
          }"></div>
      </div>
    </template>

    <div v-if="isDeletePopupShow" class="popup-bg" @click="isDeletePopupShow=false"></div>
    <yes-no-popup v-if="isDeletePopupShow" @confirm="deleteSection" @cancel="isDeletePopupShow=false">
      <div class="flex column auto justify-content-center">
        <div class="flex align-items-center">삭제 하시겠습니까?</div>
      </div>
    </yes-no-popup>
  </div>
</template>
<script>

import YesNoPopup from '@/components/yes-no-popup'
export default {
  name: 'mian',
  data () {
    return {
      sectionList:[],
      filteredSectionList:[],
      selectedSectionId:null,
      isDeletePopupShow:false,
      pageSize:5,
      currentPage:1,
      beforeX:0,
      beforeY:0,
      beforeSecionId:'',
      beforeTimestamp:0,
      kakaoLinkTimeout:null,
      keyword:'',
    }
  },
  components:{
    YesNoPopup
  },
  methods:{
    async getSections(){
      let res = await this.$api.getSections()
      this.sectionList = res.data.data
      this.filteredSectionList = this.sectionList
      this.keyword = ''
      console.log(this.sectionList)
    },
    async deleteSection(){
      if(!this.selectedSectionId){
        console.error("nothing to remove")
        return
      }
      let res = await this.$api.deleteSection({id:this.selectedSectionId})
      console.log(res)
      this.getSections()
      this.isDeletePopupShow = false
      this.$eventBus.$emit("showToast",{
        type:true,
        title:'성공',
        content:'계약이 삭제 되었습니다.'
      })
    },
    onClickDelete(section){
      this.selectedSectionId = section.id, 
      this.isDeletePopupShow = true
      $(`#mainSection${section.id}`).animate({left:'0'})
    },
    onMouseDown(e, section){
      this.beforeX = e.clientX || e.changedTouches[0].clientX
      this.beforeY = e.clientY || e.changedTouches[0].clientY
      
      this.beforeSecionId = section.id
      this.beforeTimestamp = e.timeStamp
    },
    onMouseUp(e, section){
      let x = e.clientX || e.changedTouches[0].clientX
      let y = e.clientY || e.changedTouches[0].clientY
      let ydiff = Math.abs(y - this.beforeY)
      let xdiff = this.beforeX - x
      let timediff = e.timeStamp - this.beforeTimestamp
      if(timediff<100 || (ydiff<10 && Math.abs(x - this.beforeX)<10)){
        this.onClickSection(section)
        return
      }
      if(ydiff<50){
        if(xdiff > 50)
          $(`#mainSection${this.beforeSecionId}`).animate({left:'-20vw'})
        else if(xdiff < -50)
          $(`#mainSection${this.beforeSecionId}`).animate({left:'0'})
      }
    },
    sendKakaoLink(id){
       let that = this
        if( this.kakaoLinkTimeout){
          clearTimeout(this.kakaoLinkTimeout)
        }
        this.kakaoLinkTimeout = setTimeout(function(){
          that.$eventBus.$emit("showToast",{
            type:false,
            title:'실패',
            content:`카카오톡 설치를 확인해 주세요. <br/>태블릿에서는 카카오톡을 실행할 수 없습니다.`
          })
        },1000)

        Kakao.Link.sendDefault({
          objectType: 'feed',
          content:{
            title: '쑤코어 초대장',
            description: '초대장이 도착했습니다!',
            imageUrl: `${API_URL}/uploads/soocore`,
            link: {
              mobileWebUrl: `${WEB_URL}/#/login?id=` + id,
              webUrl: `${WEB_URL}/#/login?id=` + id,
              androidExecParams:'id='+id,
              iosExecParams:'id='+id,
            },
          },
          callback:function(){
            that.$eventBus.$emit("showToast",{
              type:true,
              title:'성공',
              content:`초대를 완료했습니다.`
            })
          },
        })
    },
    checkSection(section){//success : 1, ongoin : 0, fail : -1
      if(section.score >= section.goalpoint){
       return 1
      }else{
        if(!section.endtime || section.endtime >= this.$moment().format("YYYY-MM-DD")){
          return 0
        }else{
          return -1
        }
      }
    },
    getProgressWidth(goal,score){
      let per  = parseInt(score*100/goal)
      per = per > 100 ? 100 : per
      return per+'%'
    },
    async getKakaoFrinds(){
      let res = await this.$api.getKakaoFrinds()
      console.log(res.data)
      if(res.data.code == -402){
        window.location.href = res.data.uri
      }else if(res.data.code == -401){
        let res = await this.$api.refreshKakaoToken()
        console.log("#######refreshKakaoToken Res", res)
        if(!res.data.kakaoToken){
          this.$store.commit('me', '')
          this.$store.commit('kakaoToken', '')
          if(res.data.kakaoTokenRefresh){
            this.$store.commit('kakaoTokenRefresh', res.data.kakaoTokenRefresh)
          }
          this.$store.commit('accessToken', '')
          this.$router.push({ name: 'login'})
        }else{
          this.$store.commit('kakaoToken', res.data.kakaoToken)
          if(res.data.kakaoTokenRefresh){
            this.$store.commit('kakaoTokenRefresh', res.data.kakaoTokenRefresh)
          }
        }
      }
    },
    onClickSection(section){
      if(section.isCreate) {
        this.$router.push({name:'detail', query: { id: section.id }})
      }else {
        this.sendKakaoLink(section.id)
      }
    },
    leftPage(){
      console.log(this.currentPage)
      if(this.currentPage<=1)return
      this.currentPage--
    },
    rightPage(){
      console.log(this.currentPage)
      if((this.currentPage)*this.pageSize >= this.sectionList.length) return
      this.currentPage++
    },
    async refresh(e){
      await this.getSections()
      await this.getKakaoFrinds()
      this.$refs.scroller.finishPullToRefresh()
    },
    visibilityHandler(){
      if (document.visibilityState != 'visible') {
        if(this.kakaoLinkTimeout){
          clearTimeout(this.kakaoLinkTimeout)
        }
        this.$eventBus.$emit("hideToast")
      }
    },
    serachKeyword(){
      console.log("searchKeyword")
      let that = this
      this.filteredSectionList = this.sectionList.filter(function(value){
        return value.a_name.indexOf(that.keyword)>=0 || value.b_name.indexOf(that.keyword)>=0 || value.goal.indexOf(that.keyword)>=0
      })
    },
    onKeydown(e){
      if (event.which == 13 || event.keyCode == 13) {
        this.serachKeyword()
      }
    },
  },
  async mounted(){
    this.$eventBus.$emit("showLoading")
    await this.getSections()
    await this.getKakaoFrinds()
    this.$eventBus.$emit("hideLoading")
    $(".nano").nanoScroller()
    document.addEventListener("visibilitychange",this.visibilityHandler)
  },
}
</script>

<style scoped lang="scss">
.content{
  margin-bottom:4vw;
  border-radius:2vw;
  box-shadow: 0 0 6px 0 rgba(33, 38, 46, 0.3);
  background-color: #ffffff;
  &:first-child{
    margin-top:1vw;
  }
  &:last-child{
    margin-bottom:12vw;
  }
  position:relative;
}

.circle{
background:#D8695E;
width:8vw;
height:8vw;
border-radius: 50%;
color:#ffffff;
margin-right:2vw;
}
.progress-bar-bg{
  height:6vw;
  background:#D9D9D9;
  border-radius: 2vw;
  margin-top:4vw;
  margin-bottom:2vw;
}
.progress-bar{
  height:100%;
  width:0;
  background:#F2D677;
  border-radius: 2vw;
  border: 2px dotted #D8695E;
}
.score-text{
  font-size:4vw;
  height:4vw;
  line-height: 4vw;
  margin-bottom:1vw;
  color:#595959;
}
.goal-text{
  font-size:5vw;
  height:5vw;
  line-height: 5vw;
  color:#000000;
}
.invite-mask, .fail-mask, .success-mask{
  background:rgba(0,0,0,0.7);
  width:100%;
  height:100%;
  position: absolute;
  left:0;
  top:0;
  font-size: 8vw;
  border-radius:2vw;
  color:#ffffff;
}
.fail-mask{
  background:rgba(0,0,0,0.7);
  font-size: 12vw;
  color:#D8695E;
}
.success-mask{
  background:rgba(0,0,0,0.7);
  font-size: 12vw;
  color:#F2D677;
  border: 1vw dotted #F2D677;
}

</style>
